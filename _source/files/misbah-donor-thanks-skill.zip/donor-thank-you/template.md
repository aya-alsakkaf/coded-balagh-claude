# Letter layout

Dear {name or "supporter"},

Thank you for your gift of {amount in KWD, three decimals} to {campaign}. {What it paid for, in one sentence.}
{One warm line of thanks.}

Receipt: {receipt number}

With thanks,
Misbah Charity Society
