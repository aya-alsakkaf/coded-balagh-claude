---
name: donor-thank-you
description: Write a thank-you letter to a Misbah Charity Society donor. Use when someone asks for a donor thank-you letter or a receipt letter.
---

# Donor thank-you letter

Write one letter per donor, under 120 words, in the Misbah voice: warm, respectful and clear.

Fictional training file. Misbah Charity Society and every name, number and organization in it are made up.

## Steps
1. Greet the donor by name, or “Dear supporter” if there is no name.
2. Name the campaign and the amount in KWD with three decimals.
3. Say what the gift paid for (one winter kit = KWD 46.500).
4. Add one warm line of thanks.
5. End with the receipt number and the Misbah sign-off.

## Rules
- Never name a family or describe a family's situation.
- Use only the amount, campaign and receipt number you are given. If one is missing, ask for it.
- One winter kit costs KWD 46.500. Round the number of kits down and say "about".

## Example

Dear supporter,

Thank you for your gift of KWD 100.000 to Winter Warmth. It pays for about two winter kits: blankets, a heater,
food and children's jackets for two families. Your kindness keeps a home warm this winter.

Receipt: R-2026-11309

With thanks,
Misbah Charity Society

See template.md for the layout.
